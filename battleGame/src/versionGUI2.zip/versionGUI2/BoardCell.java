package versionGUI2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class BoardCell extends JButton implements ActionListener {

	
	@Override
	public void actionPerformed(ActionEvent e) {
		

	}

}
